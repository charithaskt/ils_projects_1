from django.apps import AppConfig


class IntranetConfig(AppConfig):
    name = 'intranet'
