from django.apps import AppConfig


class IlsapiConfig(AppConfig):
    name = 'ilsapi'
